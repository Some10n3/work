import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;

class ArraySet<T> implements Iterable<T>{
    private List<T> arr;
    private class ArraySetIterator implements Iterator<T> {
        private int itPos;                    // remember the index into the items array which hasn't been visited
        public ArraySetIterator() {itPos = 0;}
        public boolean hasNext() {
            return itPos < arr.size();
        }

        public T next(){
            return arr.get(itPos++);
        }
    }

    public ArraySet(){
        arr = new ArrayList<>();
    }

    public Iterator<T> iterator() {
        return new ArraySetIterator();
    }

    public void add(T value){
        if (!contains(value)) { arr.add(value); }
    }

    public boolean contains(T value){
        return arr.contains(value);
    }

    public int size(){ return arr.size(); }
}

public class Lect10 {
    public static void main(String[] args) {
        HashSet<Integer> hs = new HashSet<>();
        hs.add(3);
        hs.add(1);
        hs.add(12);
        for (int x: hs){
            System.out.println(x);
        }

        ArraySet<Integer> as = new ArraySet<>();
        as.add(3);
        as.add(1);
        as.add(12);
        for (int x: as){
            System.out.println(x);
        }

        /* manual iterator
        Iterator<Integer> it = as.iterator();
        while (it.hasNext()) {
            int x = it.next();
            System.out.println(x);
        }
         */
    }


}
