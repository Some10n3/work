import java.util.ArrayList;
import java.util.List;

public class ThreeCoins {
    public static List<Integer> change(int n){
        // Theorem: n-cents can be made from 5, 12, and 13-cent stamps for all n >= 20.
        // Predicate: P(n) = n-cents can be made from 5, 12, and 13-cent stamps for all n >= 20.

        if (n == 20) {
            return List.of(5, 5, 5, 5);            // Base case 1
        }
        if (n == 21) {
            return List.of(5, 5, 11);              // Base case 2
        }
        if (n == 22) {
            return List.of(5, 5, 12);              // Base case 3
        }
        if (n == 23) {
            return List.of(11, 12);                // Base case 4
        }
        if (n == 24){
            return List.of(12, 12);                // Base case 5
        }
        /*
        Inductive hypothesis: Assume that j-cents can be made with 5, 12 and 13-cent stamps for j = 20...k,
                                for some k >= 24.

        We want to show that k + 1 cents can be made with 5,12,13 stamps.
        */

        List<Integer> nminus5 = new ArrayList<>(change(n - 5));     // for cases greater than 24, add at least 1 5
        /*
        Trying some k amounts:

        25 cents = 5 + 20
        26 cents = 5 + 21
        27 cents = 5 + 22
        28 cents = 5 + 23
        29 cents = 5 + 24
        30 cents = 5 + 25  = 5 + (5 + 20)

        Using another 5-cent stamp ->  k + 1 - 5 = k - 4 left to make

        Since k >= 24,  20 <= k - 4 <= k.

        By the inductive hypothesis, k - 4 can be made from 5, 12, and 13-cent stamps.
         */
        nminus5.add(5);
        return nminus5;
        // Therefore, by mathematical induction, n-cents can be made from 5, 12, and 13-cent stamps for all n >= 20.
    }

    public static void main(String[] args){
        System.out.println(change(25));  // [5, 5, 5, 5, 5]
        System.out.println(change(26));  // [5, 5, 11, 5]
        System.out.println(change(27));  // [5, 5, 12, 5]
        System.out.println(change(28));  // [11, 12, 5]
        System.out.println(change(29));  // [12, 12, 5]
        System.out.println(change(30));  // [5, 5, 5, 5, 5, 5]
    }
}
